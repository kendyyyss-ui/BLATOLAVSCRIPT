pfc.log("PRO OPR PRICE SNIPER");
pfc.log("by CREEPER SCRIPT (Optimized)");

var КУПИТЬ = Point.get(123,123);
var ПОДТВЕРДИТЬ = Point.get(123,123);
var КООРДИНАТЫ_ЦЕНЫ = Point.get(123,123);
var ЦВЕТ_ЦЕНЫ = 123;
var ГАЛОЧКА = Point.get(123,123);
var ОК = Point.get(123,123);
var КРЕСТИК = Point.get(123,123);

var ОБНОВЛЕНИЕ_ГАЛОЧКИ = 10000;
var ЗАДЕРЖКА = 30;

// Сохранён как встроенный шаблон. Автоматическое выполнение отключено.
