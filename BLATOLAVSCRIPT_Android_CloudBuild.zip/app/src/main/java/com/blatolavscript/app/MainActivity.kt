package com.blatolavscript.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.*
import java.io.IOException

private val Bg = Color(0xFF101512)
private val Panel = Color(0xFF1B241E)
private val Accent = Color(0xFF66D18A)

class MainActivity : ComponentActivity() {
    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val masterKey = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val prefs = EncryptedSharedPreferences.create(
            this, "secure_settings", masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        setContent {
            var page by remember { mutableStateOf("Главная") }
            var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
            var chatId by remember { mutableStateOf(prefs.getString("chat", "") ?: "") }
            var status by remember { mutableStateOf("Готово к настройке") }
            var dark by remember { mutableStateOf(true) }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
                    Text("BLATOLAVSCRIPT", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black, color = Accent)
                    Text("MARKET COMPANION  •  v1.0", color = Color.LightGray)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Главная", "Скрипты", "Telegram", "Настройки").forEach {
                            Button(onClick = { page = it }, contentPadding = PaddingValues(10.dp)) {
                                Text(it)
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        when (page) {
                            "Главная" -> {
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Панель управления", fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(8.dp))
                                        Text("Статус: $status")
                                        Spacer(Modifier.height(12.dp))
                                        Text("Автоматическое выполнение игровых покупок в этой сборке отключено.",
                                            color = Color.LightGray)
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Встроенные шаблоны", fontWeight = FontWeight.Bold)
                                        Text("PRO SNIPER v3.2")
                                        Text("PRO OPR PRICE SNIPER")
                                    }
                                }
                            }
                            "Скрипты" -> {
                                ScriptCard("PRO SNIPER v3.2", "Шаблон встроен в приложение.")
                                ScriptCard("PRO OPR PRICE SNIPER", "Шаблон встроен. Координаты и цвет цены в исходнике тестовые.")
                            }
                            "Telegram" -> {
                                Text("Telegram Bot", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(token, { token = it }, label = { Text("Bot Token") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(chatId, { chatId = it }, label = { Text("Chat ID") }, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = {
                                    prefs.edit().putString("token", token).putString("chat", chatId).apply()
                                    status = "Настройки Telegram сохранены"
                                }) { Text("Сохранить") }
                                Button(onClick = {
                                    prefs.edit().putString("token", token).putString("chat", chatId).apply()
                                    sendTelegram(token, chatId) { result -> runOnUiThread { status = result } }
                                }) { Text("Отправить тест") }
                                Text("Тестовое сообщение проверяет соединение. Автоматическая отправка игровых скриншотов не подключена.",
                                    color = Color.LightGray)
                            }
                            else -> {
                                Text("Настройки", fontWeight = FontWeight.Bold)
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Тёмная тема")
                                    Switch(checked = dark, onCheckedChange = { dark = it })
                                }
                                Text("Тема интерфейса применяется сразу.")
                            }
                        }
                    }
                    Text("BLATOLAVSCRIPT • локальные настройки", color = Color.Gray)
                }
            }
        }
    }

    private fun sendTelegram(token: String, chat: String, done: (String) -> Unit) {
        if (token.isBlank() || chat.isBlank()) { done("Укажи токен и Chat ID"); return }
        val body = FormBody.Builder().add("chat_id", chat)
            .add("text", "BLATOLAVSCRIPT: тестовое подключение успешно.")
            .build()
        val request = Request.Builder().url("https://api.telegram.org/bot$token/sendMessage").post(body).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) { done("Ошибка сети: ${e.message}") }
            override fun onResponse(call: Call, response: Response) {
                response.use { done(if (it.isSuccessful) "Telegram подключён" else "Telegram вернул ошибку: ${it.code}") }
            }
        })
    }
}

@Composable
private fun ScriptCard(title: String, description: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Accent)
            Spacer(Modifier.height(6.dp))
            Text(description)
            Spacer(Modifier.height(8.dp))
            Text("Встроенный шаблон • просмотр/хранение", color = Color.LightGray)
        }
    }
}
